[← 超时](5-Timeout-CN.md) | 调试[(English)](6-Debug-EN.md) | [并发 →](7-Concurrent-CN.md)
***

# 调试
如果环境变量 `DEBUG=sdk` 存在, 所有的请求都将启用调试模式。

***
[← 超时](5-Timeout-CN.md) | 调试[(English)](6-Debug-EN.md) | [并发 →](7-Concurrent-CN.md)
