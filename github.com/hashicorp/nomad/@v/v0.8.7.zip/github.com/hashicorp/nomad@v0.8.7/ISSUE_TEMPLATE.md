If you have a question, prepend your issue with `[question]` or preferably use the [nomad mailing list](https://www.nomadproject.io/community.html).

If filing a bug please include the following:

### Nomad version
Output from `nomad version`

### Operating system and Environment details

### Issue

### Reproduction steps

### Nomad Server logs (if appropriate)

### Nomad Client logs (if appropriate)

### Job file (if appropriate)
