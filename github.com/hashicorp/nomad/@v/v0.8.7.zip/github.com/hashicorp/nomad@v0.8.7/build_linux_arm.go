// +build linux,cgo

// #cgo LDFLAGS: -mfloat-abi=hard

package main
