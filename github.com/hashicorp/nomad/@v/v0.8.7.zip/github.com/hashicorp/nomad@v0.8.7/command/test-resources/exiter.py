import sys

sys.exit(int(sys.argv[1]))
