Simply run the Nomad Server and Clients from this directory and the created cluster will be using TLS.
