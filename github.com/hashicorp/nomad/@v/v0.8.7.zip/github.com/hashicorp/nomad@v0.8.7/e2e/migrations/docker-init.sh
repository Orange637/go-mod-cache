
docker build -t nomad-e2e .
