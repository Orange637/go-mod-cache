// +build !memprofiler

package command

func (c *ServerCommand) startMemProfiler() {
}
