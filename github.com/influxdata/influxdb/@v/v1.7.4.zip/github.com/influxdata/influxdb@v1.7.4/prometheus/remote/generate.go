package remote

//go:generate protoc -I$GOPATH/src -I. --gogofaster_out=. remote.proto
