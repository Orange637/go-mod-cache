// Based on powerman/rpc-codec:
// The MIT License (MIT)
// Copyright (c) 2015 Alex Efros
package jsonrpc2
