# Example

The example API router uses [File](https://godoc.org/github.com/micro/go-os/config/source/file) config source to load routes.json and 
runs on 127.0.0.1:10001. If you hit / you'll be redirected to example.com as expected.
