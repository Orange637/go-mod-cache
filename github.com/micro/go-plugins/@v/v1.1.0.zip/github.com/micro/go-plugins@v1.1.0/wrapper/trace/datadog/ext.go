package datadog

const (
	// tagendpoint = "micro.endpoint"
	// tagservice  = "micro.service"
	// tagMethod  = "micro.method"
	tagStatus  = "micro.status"
	tagRole    = "micro.role"
	tagID      = "micro.id"
	tagVersion = "micro.version"
)
