Use the following commands to regenerate the README.

```bash
$ go get github.com/rakyll/embedmd
$ embedmd -w ../../README.md
```
