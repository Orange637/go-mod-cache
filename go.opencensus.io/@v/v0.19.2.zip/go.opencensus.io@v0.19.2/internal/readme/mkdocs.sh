#!/bin/sh

embedmd source.md > ../../README.md
