package pear

import _ "fruit.io/banana"
